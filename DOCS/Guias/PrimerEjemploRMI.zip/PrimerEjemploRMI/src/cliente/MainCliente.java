package cliente;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Properties;

import cuenta.ICuentaBancaria;
import excepciones.MontoInvalidoException;

public class MainCliente 
{
	public static void main(String[] args)
	{
		try 
		{
			//obtengo ip y puerto de un archivo de configuracion
			Properties p = new Properties();
			String nomArch = "config/config.properties";
			p.load (new FileInputStream (nomArch));
			String ip = p.getProperty("ipServidor");
			String puerto = p.getProperty("puertoServidor");
			String ruta = "//" + ip + ":" + puerto + "/cuenta";
			
			//accedo remotamente a la cuenta bancaria publicada en el servidor
			ICuentaBancaria cuenta = (ICuentaBancaria) Naming.lookup(ruta);
			cuenta.depositar(1500);
			cuenta.retirar(500);
			System.out.println("Saldo: " + cuenta.getSaldo());
		}
		catch (MalformedURLException e) // si la ruta no esta bien formada
		{
			e.printStackTrace();
		}
		catch (RemoteException e) // si ocurre cualquier problema de red
		{
			e.printStackTrace();
		}
		catch (NotBoundException e) // si la ruta esta bien formada pero el servidor esta bajo
		{
			e.printStackTrace();
		}
		catch (FileNotFoundException e) // si no encuentra el archivo de configuracion
		{
			e.printStackTrace();
		}
		catch (IOException e) // si ocurre cualquier otro error de E/S
		{
			e.printStackTrace();
		} 
		catch (MontoInvalidoException e) // si intento manipular un monto invalido
		{
			System.out.println(e.getMensaje()); // muestro al usuario el mensaje personalizado
		}
	}
}
