package cuenta;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import excepciones.MontoInvalidoException;

public class CuentaBancaria extends UnicastRemoteObject implements ICuentaBancaria
{
	private static final long serialVersionUID = 1L;
	private double saldo;	
	
	public CuentaBancaria() throws RemoteException
	{
		saldo = 500;
	}
	
	public void depositar(double monto) throws RemoteException, MontoInvalidoException
	{
		if (monto < 0)
		{
			String msg = "el monto no puede ser negativo";
			throw new MontoInvalidoException(msg);
		}
		saldo = saldo + monto;
	}
	
	public void retirar(double monto) throws RemoteException, MontoInvalidoException
	{
		if (monto < 0)
		{
			String msg = "el monto no puede ser negativo";
			throw new MontoInvalidoException(msg);
		}
		if (monto > saldo)
		{
			String msg = "el monto no puede superar al saldo";
			throw new MontoInvalidoException(msg);
		}
		saldo = saldo - monto;
	}
	
	public double getSaldo() throws RemoteException
	{
		return saldo;
	}
}
