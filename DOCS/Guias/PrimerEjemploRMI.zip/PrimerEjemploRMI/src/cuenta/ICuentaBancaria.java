package cuenta;

import java.rmi.Remote;
import java.rmi.RemoteException;

import excepciones.MontoInvalidoException;

public interface ICuentaBancaria extends Remote
{
	public void depositar(double monto) throws RemoteException, MontoInvalidoException;
	public void retirar (double monto) throws RemoteException, MontoInvalidoException;
	public double getSaldo() throws RemoteException;
}