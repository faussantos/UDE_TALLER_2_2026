package excepciones;

public class MontoInvalidoException extends Exception {

	private static final long serialVersionUID = 1L;
	private String mensaje;
	
	public MontoInvalidoException(String mensaje)
	{
		this.mensaje = mensaje;
	}
	
	public String getMensaje ()
	{
		return this.mensaje;
	}
}