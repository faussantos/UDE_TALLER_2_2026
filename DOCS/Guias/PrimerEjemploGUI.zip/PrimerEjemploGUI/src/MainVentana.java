
public class MainVentana {

	public static void main(String[] args) {
		VentanaMensaje v = new VentanaMensaje(); 
		v.setVisible(true);
	}

}
