import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaMensaje {

	private JLabel labelMensaje;
	private JLabel labelTipo;
	private JTextField textFieldMensaje;
	private JCheckBox chkboxTipo; 
	private JButton btnIngresar; 	
	private JFrame frame;
	
	private void initialize() {
		frame = new JFrame();
		Container panel = frame.getContentPane();
		panel.setBackground(new Color(240, 248, 255));
		frame.setTitle("Ingreso de Mensaje");
		frame.setResizable(false);
		frame.setBounds(100, 100, 273, 128);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel.setLayout(null);
		
		labelMensaje = new JLabel("Mensaje:");
		labelMensaje.setBounds(10, 11, 83, 14);
		panel.add(labelMensaje);
		
		labelTipo = new JLabel("Tipo mensaje:");
		labelTipo.setBounds(10, 36, 83, 14);
		panel.add(labelTipo);
		
		textFieldMensaje = new JTextField();
		textFieldMensaje.setBounds(103, 8, 148, 20);
		panel.add(textFieldMensaje);
		
		chkboxTipo = new JCheckBox("Es especial?");
		chkboxTipo.setBackground(new Color(240, 248, 255));
		chkboxTipo.setBounds(102, 32, 97, 23);
		panel.add(chkboxTipo);
		
		btnIngresar = new JButton("INGRESAR");
		btnIngresar.setFont(new Font("Arial", Font.BOLD, 12));
		btnIngresar.setBackground(new Color(173, 216, 230));
		btnIngresar.setBounds(79, 65, 120, 23);
		panel.add(btnIngresar);

		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mensaje = textFieldMensaje.getText();
				boolean esEspecial = chkboxTipo.isSelected();
				if (esEspecial)
					mensaje = "ESPECIAL: " + mensaje;
				JOptionPane.showMessageDialog(frame, mensaje);
			}
		});

	}
	
	public void setVisible (boolean b) {
		frame.setVisible(b);
	}

	public VentanaMensaje() {
		this.initialize();
		this.setVisible(false);
	}
}
